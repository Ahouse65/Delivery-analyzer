import streamlit as st
import pandas as pd
from pathlib import Path
import uuid

# --- Setup ---
st.set_page_config(page_title="Delivery App", page_icon="🚚", layout="centered")
st.title("🚚 Simple Delivery App")

ORDERS_FILE = Path("orders.csv")

# Load existing orders
if ORDERS_FILE.exists():
    orders_df = pd.read_csv(ORDERS_FILE)
else:
    orders_df = pd.DataFrame(columns=["OrderID", "Name", "Address", "Item", "Quantity", "Status"])

# --- Sidebar Menu ---
st.sidebar.title("Menu")
page = st.sidebar.radio("Go to:", ["Place Order", "Track Order", "Admin Dashboard"])

# --- Page: Place Order ---
if page == "Place Order":
    st.header("📦 Place a New Order")
    name = st.text_input("Your Name")
    address = st.text_area("Delivery Address")
    item = st.selectbox("Select Item", ["Pizza", "Burger", "Drinks", "Groceries"])
    quantity = st.number_input("Quantity", min_value=1, step=1)

    if st.button("Submit Order"):
        if name.strip() == "" or address.strip() == "":
            st.error("⚠️ Please provide both name and address.")
        else:
            order_id = str(uuid.uuid4())[:8]  # Short unique ID
            new_order = pd.DataFrame(
                [[order_id, name, address, item, quantity, "Pending"]],
                columns=orders_df.columns,
            )
            orders_df = pd.concat([orders_df, new_order], ignore_index=True)
            orders_df.to_csv(ORDERS_FILE, index=False)
            st.success(f"✅ Order placed! Your Order ID is: **{order_id}**")

# --- Page: Track Order ---
elif page == "Track Order":
    st.header("🔍 Track Your Order")
    order_id = st.text_input("Enter your Order ID")
    if st.button("Track"):
        if order_id in orders_df["OrderID"].values:
            order = orders_df[orders_df["OrderID"] == order_id].iloc[0]
            st.info(f"📦 Order for {order['Quantity']} x {order['Item']} is currently **{order['Status']}**.")
        else:
            st.error("❌ Order not found. Please check your Order ID.")

# --- Page: Admin Dashboard ---
elif page == "Admin Dashboard":
    st.header("📊 Admin Dashboard")
    if not orders_df.empty:
        st.dataframe(orders_df)

        # Select order to update or delete
        order_ids = orders_df["OrderID"].tolist()
        selected_order = st.selectbox("Select an Order", order_ids)

        if selected_order:
            current_status = orders_df.loc[orders_df["OrderID"] == selected_order, "Status"].values[0]
            new_status = st.selectbox(
                "Update Status",
                ["Pending", "On the way", "Delivered"],
                index=["Pending", "On the way", "Delivered"].index(current_status)
            )

            col1, col2 = st.columns(2)

            with col1:
                if st.button("💾 Save Status Update"):
                    orders_df.loc[orders_df["OrderID"] == selected_order, "Status"] = new_status
                    orders_df.to_csv(ORDERS_FILE, index=False)
                    st.success(f"✅ Order {selected_order} status updated to {new_status}!")

            with col2:
                if st.button("🗑️ Delete Order"):
                    orders_df = orders_df[orders_df["OrderID"] != selected_order]
                    orders_df.to_csv(ORDERS_FILE, index=False)
                    st.warning(f"🗑️ Order {selected_order} has been deleted.")
    else:
        st.info("No orders yet.")
