# 🚚 Delivery App (Streamlit)

## Setup Instructions

### 1. Install Python & pip
On Linux (e.g., Chromebook Linux terminal):
```bash
sudo apt update && sudo apt install python3 python3-pip -y
```

### 2. Install Dependencies
```bash
pip3 install -r requirements.txt
```

### 3. Run the App
```bash
streamlit run app.py
```

Then open the link in your browser (http://localhost:8501).

---
✅ Files included:
- app.py — main delivery app code (with order saving + admin status updates + delete feature)
- requirements.txt — dependencies (Streamlit, pandas)
- README.md — setup instructions
